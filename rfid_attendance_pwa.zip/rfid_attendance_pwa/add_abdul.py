from werkzeug.security import generate_password_hash
import pymysql

# Connect to MySQL
conn = pymysql.connect(
    host="127.0.0.1",
    user="root",
    password="12345678",
    database="rfid_attendance_db",  # ✅ Make sure this is included
    connect_timeout=5
)

cursor = conn.cursor()
hashed_password = generate_password_hash("1234")

# Insert admin user
cursor.execute(
    "INSERT INTO admins (username, password) VALUES (%s, %s)",
    ("abdul", hashed_password)
)

conn.commit()
print("✅ Admin added successfully.")

cursor.close()
conn.close()

