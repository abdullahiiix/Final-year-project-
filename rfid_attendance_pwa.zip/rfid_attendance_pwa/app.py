from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from flask_cors import CORS
from db_config import get_connection
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

app = Flask(__name__)
CORS(app)
app.secret_key = "super_secret_key"

# =====================================================
# SECTION 1: Public Routes
# =====================================================
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/attendance", methods=["POST"])
def mark_attendance():
    data = request.json
    tag_id = data.get("tag_id", "").strip()

    print(f"📥 Tag received: {tag_id}")
    if not tag_id:
        return jsonify({"error": "No tag provided"}), 400

    # Check time is between 8:00 AM and 9:00 AM
    now = datetime.now()
    if not (now.hour == 8):
        return jsonify({"error": "❌ Attendance can only be marked between 8:00 AM and 9:00 AM."}), 403

    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT name FROM students WHERE tag_id = %s", (tag_id,))
        student = cursor.fetchone()
        if not student:
            return jsonify({"error": f"No student found with tag {tag_id}"}), 404

        student_name = student[0]
        date_today = now.date()

        # Prevent duplicate attendance for today
        cursor.execute(
            "SELECT id FROM attendance WHERE tag_id = %s AND date = %s",
            (tag_id, date_today)
        )
        if cursor.fetchone():
            return jsonify({"message": "🟡 Attendance already marked for today."})

        # Insert new attendance
        cursor.execute(
            "INSERT INTO attendance (tag_id, name, date, time) VALUES (%s, %s, CURDATE(), CURTIME())",
            (tag_id, student_name)
        )
        conn.commit()
        return jsonify({"message": f"✅ Attendance marked for {student_name}!"})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()


# =====================================================
# SECTION 2: Login & Session Management
# =====================================================
@app.route("/login", methods=["GET", "POST"])
def login():
    role = request.args.get("role") or request.form.get("role")
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        conn = get_connection()
        cursor = conn.cursor()
        try:
            if role == "admin":
                cursor.execute("SELECT password FROM admins WHERE username = %s", (username,))
                result = cursor.fetchone()
                if result and check_password_hash(result[0], password):
                    session["admin"] = username
                    return redirect(url_for("dashboard"))

            elif role == "parent":
                cursor.execute("SELECT password FROM parents WHERE email = %s", (username,))
                result = cursor.fetchone()
                if result and result[0] == password:
                    session["parent"] = username
                    return redirect(url_for("parent_dashboard"))

            elif role == "student":
                cursor.execute("SELECT tag_id FROM students WHERE tag_id = %s", (username,))
                result = cursor.fetchone()
                if result:
                    if password == "1234":
                        session["student"] = username
                        return redirect(url_for("student_dashboard"))
                    else:
                        return "Incorrect password for student", 401
                else:
                    return "Student not found", 404

        except Exception as e:
            return f"Error: {e}", 500
        finally:
            cursor.close()
            conn.close()

        return "Invalid credentials", 401  # Only reached if no roles matched or checks failed

    return render_template("login.html", role=role or "admin")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

# =====================================================
# SECTION 3: Admin Dashboard & Report Viewing
# =====================================================
@app.route("/dashboard")
def dashboard():
    if not session.get("admin"):
        return redirect(url_for("login", role="admin"))
    return render_template("dashboard.html")

@app.route("/report")
def report():
    if not session.get("admin"):
        return redirect(url_for("login", role="admin"))
    return render_template("report.html")

@app.route("/api/report")
def get_report():
    if not session.get("admin"):
        return jsonify({"error": "Unauthorized"}), 401
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            SELECT name, tag_id,
                   TIME_FORMAT(time, '%h:%i %p') AS formatted_time,
                   DATE_FORMAT(date, '%Y-%m-%d') AS formatted_date
            FROM attendance
            ORDER BY date DESC, time DESC
        """)
        rows = cursor.fetchall()
        report = [{"name": r[0], "tag_id": r[1], "time": r[2], "date": r[3]} for r in rows]
        return jsonify(report)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

# =====================================================
# SECTION 4: Parent Management (with Multi-Student Links)
# =====================================================

@app.route("/api/parents", methods=["POST"])
def create_parent():
    data = request.get_json()
    conn = get_connection()
    cursor = conn.cursor()
    try:
        # Insert parent
        cursor.execute(
            "INSERT INTO parents (name, email, password) VALUES (%s, %s, %s)",
            (data["name"], data["email"], data["password"])
        )
        # Link students
        for tag_id in data.get("student_tags", []):
            cursor.execute(
                "INSERT INTO parent_student_links (parent_email, student_tag_id) VALUES (%s, %s)",
                (data["email"], tag_id)
            )
        conn.commit()
        return jsonify({"message": "✅ Parent and linked students added!"})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route("/api/parents", methods=["GET"])
def get_parents():
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, name, email FROM parents")
        parents = []
        for row in cursor.fetchall():
            cursor.execute("SELECT student_tag_id FROM parent_student_links WHERE parent_email = %s", (row[2],))
            student_tags = [r[0] for r in cursor.fetchall()]
            parents.append({
                "id": row[0],
                "name": row[1],
                "email": row[2],
                "student_tags": student_tags
            })
        return jsonify(parents)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route("/api/parents/<int:id>", methods=["PUT"])
def update_parent(id):
    data = request.json
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT email FROM parents WHERE id=%s", (id,))
        old_email = cursor.fetchone()
        if not old_email:
            return jsonify({"error": "Parent not found"}), 404
        old_email = old_email[0]

        cursor.execute(
            "UPDATE parents SET name=%s, email=%s, password=%s WHERE id=%s",
            (data["name"], data["email"], data["password"], id)
        )
        cursor.execute("DELETE FROM parent_student_links WHERE parent_email=%s", (old_email,))
        for tag_id in data.get("student_tags", []):
            cursor.execute(
                "INSERT INTO parent_student_links (parent_email, student_tag_id) VALUES (%s, %s)",
                (data["email"], tag_id)
            )
        conn.commit()
        return jsonify({"message": "✅ Parent and linked students updated!"})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route("/api/parents/<int:id>", methods=["DELETE"])
def delete_parent(id):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT email FROM parents WHERE id=%s", (id,))
        email = cursor.fetchone()
        if email:
            cursor.execute("DELETE FROM parent_student_links WHERE parent_email=%s", (email[0],))
        cursor.execute("DELETE FROM parents WHERE id=%s", (id,))
        conn.commit()
        return jsonify({"message": "🗑️ Parent deleted with links!"})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route("/api/parent/attendance")
def parent_attendance():
    if not session.get("parent"):
        return jsonify({"error": "Unauthorized"}), 401

    parent_email = session["parent"]
    conn = get_connection()
    cursor = conn.cursor()
    try:
        # Get all student tag IDs linked to this parent
        cursor.execute("SELECT student_tag_id FROM parent_student_links WHERE parent_email = %s", (parent_email,))
        tag_rows = cursor.fetchall()
        if not tag_rows:
            return jsonify({"error": "No linked students found"})

        student_tags = [r[0] for r in tag_rows]

        # Get student names for those tags
        cursor.execute("SELECT tag_id, name FROM students WHERE tag_id IN (%s)" % ",".join(["%s"]*len(student_tags)), student_tags)
        student_info = {row[0]: row[1] for row in cursor.fetchall()}

        # Fetch attendance for each student
        student_records = {}
        for tag in student_tags:
            cursor.execute("SELECT date, time FROM attendance WHERE tag_id = %s ORDER BY date DESC", (tag,))
            records = [{"date": str(r[0]), "time": str(r[1]), "status": "Present"} for r in cursor.fetchall()]
            student_records[tag] = {
                "name": student_info.get(tag, "Unknown"),
                "tag_id": tag,
                "records": records
            }

        return jsonify({
            "parent": parent_email,
            "students": list(student_records.values())
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()


# =====================================================
# SECTION 5: Student Management
# =====================================================
@app.route("/api/students", methods=["POST"])
def create_student():
    data = request.get_json()
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO students (name, class, tag_id) VALUES (%s, %s, %s)",
            (data["name"], data["class"], data["tag_id"])
        )
        conn.commit()
        return jsonify({"message": "✅ Student added successfully!"})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route("/api/students", methods=["GET"])
def get_students():
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, name, class, tag_id FROM students")
        rows = cursor.fetchall()
        students = [{"id": r[0], "name": r[1], "class": r[2], "tag_id": r[3]} for r in rows]
        return jsonify(students)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route("/api/students/<int:id>", methods=["PUT"])
def update_student(id):
    data = request.get_json()
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE students SET name=%s, class=%s, tag_id=%s WHERE id=%s",
            (data["name"], data["class"], data["tag_id"], id)
        )
        conn.commit()
        return jsonify({"message": "✅ Student updated successfully!"})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route("/api/students/<int:id>", methods=["DELETE"])
def delete_student(id):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM students WHERE id=%s", (id,))
        conn.commit()
        return jsonify({"message": "🗑️ Student deleted successfully!"})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()
        
        
# =====================================================
# SECTION 6: Admin Management
# =====================================================
@app.route("/api/admins", methods=["POST"])
def create_admin():
    data = request.json
    username = data["username"]
    password = generate_password_hash(data["password"])
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO admins (username, password) VALUES (%s, %s)", (username, password))
        conn.commit()
        return jsonify({"message": "✅ Admin added successfully!"})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()

@app.route("/api/admins", methods=["GET"])
def get_admins():
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT id, username FROM admins")
        rows = cursor.fetchall()
        admins = [{"id": r[0], "username": r[1]} for r in rows]
        return jsonify(admins)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()
        
# =====================================================
# SECTION 7: Student Attendance API
# =====================================================
@app.route("/api/student/attendance")
def student_attendance():
    if not session.get("student"):
        return jsonify({"error": "Unauthorized"}), 401

    tag_id = session["student"]
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT name FROM students WHERE tag_id = %s", (tag_id,))
        name_result = cursor.fetchone()
        student_name = name_result[0] if name_result else "Student"

        cursor.execute("""
            SELECT date, time
            FROM attendance
            WHERE tag_id = %s
            ORDER BY date DESC, time DESC
        """, (tag_id,))
        rows = cursor.fetchall()
        records = [
            {
                "date": str(r[0]),
                "time": str(r[1]),
                "status": "Present"
            }
            for r in rows
        ]

        return jsonify({
            "student": student_name,
            "records": records
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()
        
@app.route("/api/student/attendance/<tag_id>")
def get_student_attendance(tag_id):
    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT date, time FROM attendance WHERE tag_id = %s ORDER BY date DESC", (tag_id,))
        rows = cursor.fetchall()
        records = [{"date": str(r[0]), "time": str(r[1]), "status": "Present"} for r in rows]
        return jsonify(records)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()
        conn.close()


# =====================================================
# SECTION 8: Dashboards
# =====================================================
@app.route("/parent-dashboard")
def parent_dashboard():
    if not session.get("parent"):
        return redirect(url_for("login", role="parent"))
    return render_template("parent_dashboard.html", parent=session["parent"])

@app.route("/student-dashboard")
def student_dashboard():
    if not session.get("student"):
        return redirect(url_for("login", role="student"))

    tag_id = session["student"]
    print("🧾 Student session tag ID:", tag_id) 

    conn = get_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT name FROM students WHERE tag_id = %s", (tag_id,))
        result = cursor.fetchone()
        student_name = result[0] if result else "Unknown"
        return render_template("student_dashboard.html", student_name=student_name, tag_id=tag_id)
    finally:
        cursor.close()
        conn.close()

# =====================================================
# Run the App
# =====================================================
if __name__ == "__main__":
    app.run(debug=True)
