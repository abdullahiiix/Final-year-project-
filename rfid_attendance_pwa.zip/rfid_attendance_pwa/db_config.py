import pymysql

def get_connection():
    print("📡 Attempting to connect via PyMySQL...")
    return pymysql.connect(
        host="127.0.0.1",
        user="root",
        password="12345678",
        database="rfid_attendance_db",
        connect_timeout=5
    )
