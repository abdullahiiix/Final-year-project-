import serial
import requests

SERIAL_PORT = "COM3"     # Change this to your actual COM port
BAUD_RATE = 9600
FLASK_URL = "http://127.0.0.1:5000/api/attendance"

ser = serial.Serial(SERIAL_PORT, BAUD_RATE)
print("🔌 Listening to Arduino...")

while True:
    try:
        tag = ser.readline().decode("utf-8").strip()
        if tag:
            print(f"🆔 Tag scanned: {tag}")
            res = requests.post(FLASK_URL, json={"tag_id": tag})
            print("✅ Server response:", res.json())
    except Exception as e:
        print("❌ Error:", e)
