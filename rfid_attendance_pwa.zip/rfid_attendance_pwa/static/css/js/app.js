
// Simulate RFID tag scan with a prompt
function simulateRFIDScan() {
  const tagId = prompt("📡 Simulated RFID Scan: Enter Tag ID");

  if (tagId) {
    const statusBox = document.getElementById("status");
    statusBox.classList.remove("alert-success", "alert-danger");
    statusBox.classList.add("alert-info");
    statusBox.textContent = "Sending to server...";

    fetch('/api/attendance', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ tag_id: tagId })
    })
    .then(res => res.json())
    .then(data => {
      statusBox.classList.remove("alert-info");
      statusBox.classList.add("alert-success");
      statusBox.textContent = data.message;
    })
    .catch(err => {
      statusBox.classList.remove("alert-info");
      statusBox.classList.add("alert-danger");
      statusBox.textContent = "❌ Error: " + err.message;
    });
  }
}

// Run the scan simulation automatically when page loads
window.onload = function () {
  simulateRFIDScan();
};

