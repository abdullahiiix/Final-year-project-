from db_config import get_connection

print("▶️ Starting PyMySQL test...")

try:
    conn = get_connection()
    print("✅ Connected successfully via PyMySQL!")
    conn.close()
except Exception as e:
    print("❌ Connection failed:", e)
