import requests

FLASK_URL = "http://127.0.0.1:5000/api/attendance"

print("🟢 USB RFID Reader Active")
print("🔁 Waiting for full card scan...\n")

while True:
    try:
        tag = input("📥 Scan Tag: ").strip()
        if not tag:
            print("⚠️ No tag detected.")
            continue

        print(f"📥 Full Tag: {tag}")

        response = requests.post(FLASK_URL, json={"tag_id": tag})
        data = response.json()

        if response.status_code == 200:
            print("✅", data.get("message"))
        else:
            print("❌", data.get("error", "Unknown error"))

    except Exception as e:
        print("❌ Error:", e)
